/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.uninove.mdoo.aula3536.orientadoaevento.Classes;

/**
 *
 * @author y3c
 */
public class Cliente extends Pessoa  
{
 private int id;   
 private double renda;   

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getRenda() {
        return renda;
    }

    public void setRenda(double renda) {
        this.renda = renda;
    }
}
